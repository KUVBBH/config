## this is an Github like styles

[example](http://blog.yuuko.cn/markdown.css/public/example-github.html)

```
git clone https://github.com/iamcco/markdown.css
cd markdown.css
npm install
gulp public
```

> The style files are in **dest/** directory    
> The example is in **public/** directory
