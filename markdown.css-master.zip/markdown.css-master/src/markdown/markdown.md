# The largest heading
## The second largest heading
### The thrid heading
#### The fourth heading
##### The fifth heading
###### The smallest heading

**this is the bold text**

*this text is italicized*

~~This was misstaken text~~

**this text is _extremely_ important**

In the words of Abraham Lincoln:

> Pardon my French

Use `git status` to list all new or modified files that haven't yet been commited

Some basic Git commands are:
```
git status
git add
git commit
```

This site was built using [Github Pages](https://pages.github.com).

- George Washington
- John Adams
- Thomas Jefferson


1. James Madison
2. James Monroe
3. John Quincy Adams


1. Make my changes
   1. Fix bug
   2. Improve formatting
      * Make the heading bigger
2. Push my commits to Github
3. Open a pull request
   * Describe my changes
   * Mention all the members of my team
     * Ask for feedbackk

<ul>
    <li class="task-list-item" checked="">
        <input type="checkbox" class="task-list-item" checked="" disabled=""> Finish my changes
    </li>
    <li class="task-list-item">
        <input type="checkbox" class="task-list-item" disabled=""> Push my commits to Github
    </li>
    <li class="task-list-item">
        <input type="checkbox" class="task-list-item" disabled=""> Open a pull request
    </li>
</ul>

key  | value | desc
----- | -------- | -----
getFunc | function | get the property of the key
setFunc | function | set the property of the key
